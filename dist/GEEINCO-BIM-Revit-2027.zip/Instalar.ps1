$ErrorActionPreference = 'Stop'
$basePath = Join-Path $env:APPDATA 'Autodesk\Revit\Addins\2027'
$installPath = Join-Path $basePath 'VisorIFCLocal'
$manifestPath = Join-Path $basePath 'VisorIFCLocal.addin'
$addinId = '907cd85b-fd36-45be-9145-5bff379a63e4'
$sourceDll = Join-Path $PSScriptRoot 'bin\VisorIFC.Revit2027.dll'
if (!(Test-Path -LiteralPath $sourceDll)) { throw 'Falta el complemento compilado en bin.' }
if (Test-Path -LiteralPath $manifestPath) {
    [xml]$previous = Get-Content -LiteralPath $manifestPath -Raw
    if ($previous.RevitAddIns.AddIn.AddInId -ne $addinId) { throw 'Existe otro complemento con este nombre. No se modifico.' }
}
$buildId = (Get-FileHash -LiteralPath $sourceDll -Algorithm SHA256).Hash.Substring(0,16).ToLowerInvariant()
$versionPath = Join-Path $installPath $buildId
New-Item -ItemType Directory -Path $versionPath -Force | Out-Null
$assemblyPath = Join-Path $versionPath 'VisorIFC.Revit2027.dll'
if (!(Test-Path -LiteralPath $assemblyPath)) { Copy-Item -LiteralPath $sourceDll -Destination $assemblyPath }
if ((Get-FileHash -LiteralPath $sourceDll).Hash -ne (Get-FileHash -LiteralPath $assemblyPath).Hash) { throw 'El archivo instalado no coincide con el paquete.' }
$escapedAssembly = [System.Security.SecurityElement]::Escape($assemblyPath)
$manifest = @"
<?xml version="1.0" encoding="utf-8"?>
<RevitAddIns>
  <AddIn Type="Application">
    <Name>Visor IFC Local</Name>
    <Assembly>$escapedAssembly</Assembly>
    <AddInId>$addinId</AddInId>
    <FullClassName>VisorIFC.Revit2027.App</FullClassName>
    <VendorId>VIFC</VendorId>
    <VendorDescription>Conector al visor IFC local</VendorDescription>
  </AddIn>
</RevitAddIns>
"@
[System.IO.File]::WriteAllText($manifestPath, $manifest, [System.Text.UTF8Encoding]::new($false))
[xml]$check = Get-Content -LiteralPath $manifestPath -Raw
if (!(Test-Path -LiteralPath $check.RevitAddIns.AddIn.Assembly)) { throw 'No se encontro el archivo registrado.' }
Write-Output "Instalado: $manifestPath"
Write-Output 'Guarda tu trabajo y vuelve a abrir Revit 2027 para cargar el complemento.'
